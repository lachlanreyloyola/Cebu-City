const FALLBACK_MAP: Record<string, string> = {
  "kawasanfalls.jpg": "https://images.unsplash.com/photo-1544085311-11a028465b03?w=800&q=80",
  "aguinidfalls.jpg": "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=800&q=80",
  "inambakanfalls.jpg": "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800&q=80",
  "mantayupanfalls.jpg": "https://images.unsplash.com/photo-1433832597046-4f10e10ac764?w=800&q=80",
  "binalayanfalls.jpg": "https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=800&q=80",
  "cambaisfalls.jpg": "https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=800&q=80",
  "daofalls.jpg": "https://images.unsplash.com/photo-1473081556163-2a17de81fc97?w=800&q=80",
  "tumalogfalls.jpg": "https://images.unsplash.com/photo-1546182990-dffeafbe841d?w=800&q=80",
  "kabutonganfalls.jpg": "https://images.unsplash.com/photo-1502082553048-f009c37129b9?w=800&q=80",
  "montanezafalls.jpg": "https://images.unsplash.com/photo-1425913397330-cf8af2ff40a1?w=800&q=80",
  "kabangfalls.jpg": "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&q=80",
  "mactanisland.jpg": "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&q=80",
  "bantayanisland.jpg": "https://images.unsplash.com/photo-1439066615861-d1af74d74000?w=800&q=80",
  "malapascuaisland.jpg": "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&q=80",
  "tulangdiotisland.jpg": "https://images.unsplash.com/photo-1505118380757-91f5f5632de0?w=800&q=80",
  "olangoisland.jpg": "https://images.unsplash.com/photo-1415125721330-f6df99768bf7?w=800&q=80",
  "sumilonisland.jpg": "https://images.unsplash.com/photo-1506929562872-bb421503ef21?w=800&q=80",
  "gilutonganisland.jpg": "https://images.unsplash.com/photo-1544551763-bf30c4f82a5c?w=800&q=80",
  "caohaganisland.jpg": "https://images.unsplash.com/photo-1520116468816-95b69e847357?w=800&q=80",
  "pandanonisland.jpg": "https://images.unsplash.com/photo-1519046904884-53103b34b206?w=800&q=80",
  "pescadorisland.jpg": "https://images.unsplash.com/photo-1582967788606-a171c1080cb0?w=800&q=80",
  "capitancilloisland.jpg": "https://images.unsplash.com/photo-1501004318641-b39e6451bec6?w=800&q=80",
  "carnazaisland.jpg": "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=800&q=80",
  "gibitngilisland.jpg": "https://images.unsplash.com/photo-1516690561799-46d8f74f9abf?w=800&q=80",
  "tingkobeach.jpg": "https://images.unsplash.com/photo-1540206395-68808572332f?w=800&q=80",
  "sanremigiobeach.jpg": "https://images.unsplash.com/photo-1510414842594-a61c69b5ae57?w=800&q=80",
  "basdakubeach.jpg": "https://images.unsplash.com/photo-1520942702018-0862200e6873?w=800&q=80",
  "hiddenbeach.jpg": "https://images.unsplash.com/photo-1484821547834-40a049033446?w=800&q=80",
  "santafebeach.jpg": "https://images.unsplash.com/photo-1506953822126-027150926524?w=800&q=80",
  "panagsamabeach.jpg": "https://images.unsplash.com/photo-1551244072-5d12893278ab?w=800&q=80",
  "lambugbeach.jpg": "https://images.unsplash.com/photo-1533760881669-e0dbbd9fa180?w=800&q=80",
  "osmenapeak.jpg": "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&q=80",
  "casinopeak.jpg": "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&q=80",
  "mt_naupa.jpg": "https://images.unsplash.com/photo-1454496522488-7a8e488e8606?w=800&q=80",
  "mtmanunggal.jpg": "https://images.unsplash.com/photo-1448375240586-882707db888b?w=800&q=80",
  "kandungawpeak.jpg": "https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=800&q=80",
  "mount_kang-irag.jpg": "https://images.unsplash.com/photo-1472214222541-d510753a4707?w=800&q=80",
  "magellanscross.jpg": "https://images.unsplash.com/photo-1590001155093-a3c66ab0c3ff?w=800&q=80",
  "basilicasantonino.jpg": "https://images.unsplash.com/photo-1548625361-155deee223d0?w=800&q=80",
  "fortsanpedro.jpg": "https://images.unsplash.com/photo-1568992687947-868a62a9f521?w=800&q=80",
  "templeofleah.jpg": "https://images.unsplash.com/photo-1503177119275-0aa32b31d468?w=800&q=80",
  "siraogarden.jpg": "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800&q=80",
  "taoisttemple.jpg": "https://images.unsplash.com/photo-1547989453-11e67ffb3885?w=800&q=80",
  "10000roses.jpg": "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&q=80",
  "cebuoceanpark.jpg": "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&q=80",
  "heritagemonument.jpg": "https://images.unsplash.com/photo-1572120360610-d971b9d7767c?w=800&q=80",
  "photo-1559592413-7cec4d0cae2b.jpg": "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=1600&q=80",
  "cebumap.jpg": "https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?w=800&q=80"
};

export function resolveImageUrl(url: string): string {
  if (!url) return '';
  
  // Extract filename if it is a local windows path
  let filename = '';
  if (url.includes('\\') || url.includes('/') || url.startsWith('C:')) {
    const parts = url.split(/[\\/]/);
    filename = parts[parts.length - 1];
  } else {
    filename = url;
  }
  
  filename = filename.toLowerCase().trim();
  
  // Try to see if it is mapped to a high-quality web url
  if (FALLBACK_MAP[filename]) {
    return FALLBACK_MAP[filename];
  }
  
  // If it's already an http or https URL, return as is
  if (url.startsWith('http://') || url.startsWith('https://')) {
    return url;
  }
  
  // Otherwise, fallback
  return `https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800&q=80`;
}
